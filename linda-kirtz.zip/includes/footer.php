

<section class="copyRight">
    <div class="makeOwn">
        <div class="row">
            <div class="col-12">
                <p class="rightsMessage">&#169 <?php echo date("Y"); ?>. All Rights Reserved</p>
            </div>
        </div>
    </div>
</section>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script src="./assets/fonts/all.min.js"></script>
<script src="./assets/js/main.js"></script>